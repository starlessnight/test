/** Automatically generated file. DO NOT MODIFY */
package com.time_set_small;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}